# বাইতুল জান্নাত জামে মসজিদ — Islamic Clock

Upload these files to a GitHub repository. The "Build APK" action runs by itself;
when it finishes, open the run and download **BaitulJannat-APK** (a zip containing app-debug.apk).

Or open this folder in Android Studio and choose Build → Build APK(s).
